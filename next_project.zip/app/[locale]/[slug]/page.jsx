import React from 'react';
// استيراد المكونات الخاصة بك
import AboutUsComponent from '@/components/sections/AboutUs';
import BundlesComponent from '@/components/sections/Bundles';

export default async function DynamicPage({ params }) {
  const { locale, slug } = await params;

  const renderPageContent = () => {
    if (slug === 'aboutus' || decodeURIComponent(slug) === 'من-نحن') {
      // هنا بتبعت الـ params للمكون الداخلي عشان يعرف يشتغل Server-Side
      return <AboutUsComponent params={params} />; 
    }
    
    if (slug === 'bundles' || decodeURIComponent(slug) === 'الباقات') {
      // وهنا نفس الكلام
      return <BundlesComponent params={params} />;
    }

    return <div>الصفحة غير موجودة (404)</div>;
  };

  return (
    <main>
      {renderPageContent()}
    </main>
  );
}