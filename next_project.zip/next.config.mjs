/** @type {import('next').NextConfig} */
const nextConfig = {
  async rewrites() {
    // يمكنك هنا جلب الروابط من الباك إند ديناميكياً
    // أو وضعها بشكل ثابت كما في هذا المثال:
    return [
      {
        source: '/ar/contact-us-ar', // الرابط الذي يظهر للمستخدم في المتصفح
        destination: '/ar/contact', // المسار الفعلي داخل مجلد app
      },
      {
        source: '/en/contact-us-en',
        destination: '/en/contact',
      },
    ];
  },
};

export default nextConfig;