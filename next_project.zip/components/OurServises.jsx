"use client";

import React from "react";
import { useTranslation } from "react-i18next";
import { usePageMetadata } from "@/hooks/useMetadata";
import { useTheme } from "@emotion/react";
import DescriptionSection from "@/components/Sections/ServicesDescriptionSection";
import Feedback from "@/components/Sections/Feedback";
import ServicesSection from "@/components/Sections/ServiceSection";

// Load metadata for services page
export default function OurServices() {
  usePageMetadata('services');

  const theme = useTheme();
  const { t } = useTranslation();
  const { title1, desc1, title2, desc2, join, btn, serv1, serv2, serv3 } =
    t("OurServises");
  const who = t("who");

  return (
    <>
      <DescriptionSection />
      <ServicesSection />
      <Feedback />
    </>
  );
}