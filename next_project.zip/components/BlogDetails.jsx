"use client";

import React, { useEffect, useState, use } from "react";
import { useParams } from "next/navigation"; // استخدام Next.js navigation
import { Container, Typography, Box } from "@mui/material";
import api from "@/Api"; // استخدام المسار المطلق
import { useTheme } from "@emotion/react";
import { useTranslation } from "react-i18next";
import { applyPageMetadata } from "@/utils/metadataService"; // استخدام المسار المطلق
import MathJaxContent from "@/components/MathJaxContent"; // استخدام المسار المطلق

export default function BlogDetails({ params }) {
  // في Next.js App Router، يتم فك الـ params باستخدام use()
  const resolvedParams = use(params);
  const slug = resolvedParams?.slug;
  const lang = resolvedParams?.lang;

  const [blog, setBlog] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const theme = useTheme();
  const { i18n } = useTranslation();

  useEffect(() => {
    const fetchBlog = async () => {
      try {
        const response = await api.get(`/blog/blogs/by-slug/${slug}/?lang=${lang || i18n.language || 'ar'}`);
        setBlog(response.data);
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    };
    if (slug) {
      fetchBlog();
    }
  }, [slug, lang, i18n.language]);

  // Apply metadata based on the blog object and current language
  useEffect(() => {
    if (blog) {
      applyPageMetadata(blog);
    }

    return () => {
      document
        .querySelectorAll('meta[data-managed-by="prokeys"]')
        .forEach(tag => tag.remove());
    };
  }, [blog, i18n.language]);

  if (loading) return <Typography>Loading...</Typography>;
  if (error) return <Typography color="error">Error loading blog.</Typography>;
  if (!blog) return null;

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Typography variant="h4" sx={{ fontWeight: 700, mb: 5, fontFamily: 'Cairo, sans-serif', color: '#131F89', textAlign: "center" }}>
        {theme.direction === 'rtl' ? blog?.arabic_title : blog?.english_title}
      </Typography>
      <Box sx={{ display: "flex", justifyContent: "center", mb: 3 }}>
        <img
          src={blog.image}
          alt={blog.english_title || "Blog image"}
          style={{ maxWidth: "100%", borderRadius: 16, maxHeight: 400, objectFit: "cover" }}
        />
      </Box>
      
      <Box sx={{ 
        fontFamily: 'Cairo, sans-serif', 
        fontSize: '1.1rem', 
        color: '#333',
        "& p, & div, & span, & li & ul & ol": {
          direction: theme.direction === 'rtl' ? 'ltr' : 'rtl',
        },
      }}>
        <MathJaxContent html={theme.direction === 'rtl' ? blog?.arabic_content : blog?.english_content} />
      </Box>
    </Container>
  );
}