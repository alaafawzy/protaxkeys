"use client";

import React from 'react';
import { Grid, Container } from "@mui/material";
import { useTranslation } from "react-i18next";
import { useTheme } from "@emotion/react";
import { usePageMetadata } from "@/hooks/useMetadata";
import Bundles from '@/components/Bundles'; // أو المسار الصحيح لمكون الباقات لديك
import DescriptionSection from '@/components/Sections/BundlesDescriptionSection';
import OurSystems from '@/components/Sections/OurSystems';
import Feedback from '@/components/Sections/Feedback';

export default function BundlesPage() {
  // Load metadata for bundles page
  usePageMetadata('bundle');

  const theme = useTheme();
  const { t } = useTranslation();
  const Who = t("AboutUs");
  
  return (
    <Grid>
      <Container
        sx={{
          width: "100%",
          justifyContent: "center",
          "& > div:not(:last-child)": {
            marginBottom: "4rem",
          },
        }}
      >
        <Grid
          container
          sx={{
            justifyContent: "center",
            textAlign: "end",
            marginBottom: "3rem",
          }}
        >
          <DescriptionSection />
          <Bundles />
          <OurSystems />
          <Feedback />
        </Grid>
      </Container>
    </Grid>
  );
}