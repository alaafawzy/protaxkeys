import { Grid, Container, Box, Typography } from "@mui/material";
import Link from "next/link";
import api from '@/utils/apis';
import CTAButton from '../helpfulComp/CTAButton';
import { getPagePathsForLang } from "@/config/pagePaths";

// الصفحة تعمل بالكامل على السيرفر (Server Component)
export default async function HomeStarting({ params }) {
  // فك الـ params لمعرفة اللغة الحالية (ar أو en)
  const resolvedParams = await params;
  const lang = resolvedParams?.lang || 'ar';
  const isRtl = lang === 'rtl' || lang === 'ar';
  
  let data = {};
  try {
    const response = await api.get('/homeStarting/');
    if (response.data && response.data.length > 0) {
      data = response.data[0];
    }
  } catch (err) {
    console.error("Error fetching data on server:", err);
  }

  // مسارات الروابط بناءً على اللغة
  const prefix = `/${lang}`;
  const paths = getPagePathsForLang(lang === 'ar' ? 'ar' : 'en');
  const backendURL = 'http://127.0.0.1:8000';
  const imageUrl = data.image?.startsWith('http') ? data.image : `${backendURL}${data.image}`;

  return (
    <Grid>
      <Container>
        <Grid container sx={{ justifyContent: { xs: "center", md: "space-between" } }}>
          
          {/* تم إزالة item من هنا */}
          <Grid md={5} xs={11}>
            <Box
              sx={{
                width: "100%",
                height: "100%",
                backgroundImage: `url(${imageUrl || '/images/landingnew.png'})`,
                backgroundSize: "contain",
                backgroundRepeat: "no-repeat",
                position: "relative",
                minHeight: "300px"
              }}
            />
          </Grid>

          {/* تم إزالة item من هنا أيضاً */}
          <Grid md={6.5} xs={11} sx={{ display: "flex", flexDirection: "column", alignItems: "end", direction: isRtl ? 'rtl' : 'ltr' }}>
            <Box sx={{ fontSize: { xs: "1.5rem", md: "42px" }, fontWeight: "700", color: "#27307F", marginBottom: "2rem", textAlign: isRtl ? 'right' : 'left' }}>
              {isRtl ? data.arabic_title : data.english_title}
            </Box>
            
            <Typography variant="h5" sx={{ fontWeight: "bold", color: "#4F4F4F", marginBottom: "1rem", textAlign: isRtl ? 'right' : 'left' }}>
              {isRtl ? data.arabic_subtitle : data.english_subtitle}
            </Typography>
            
            <Box sx={{ fontSize: "20px", marginBottom: "2rem", textAlign: isRtl ? 'right' : 'left' }}>
              {isRtl ? data.arabic_description : data.english_description}
            </Box>

            <Box sx={{ marginTop: "2rem", textAlign: "center", marginBottom: "3rem" }}>
              <Link href={`${prefix}/${paths.contact}`} style={{ textDecoration: 'none' }}>
                <CTAButton
                  label={lang === 'ar' ? 'احجز جلستك المجانية' : 'Book Your Free Session'}
                />
              </Link>
            </Box>
          </Grid>

        </Grid>
      </Container>
    </Grid>
  );
}