import React from "react";
import { Box, Container, Typography } from "@mui/material";
import Link from "next/link";
import CTAButton from "@/components/helpfulComp/CTAButton";
import { getPagePathsForLang } from "@/config/pagePaths";

export default async function HowWeWork({ params }) {
  // استقبال اللغة من الـ params (افتراضياً ar)
  const resolvedParams = await params;
  const lang = resolvedParams?.lang || 'ar';
  const isRtl = lang === 'ar';
  
  const prefix = `/${lang}`;
  const paths = getPagePathsForLang(lang);

  // نصوص الترجمة الخاصة بهذا القسم على السيرفر
  const content = {
    ar: {
      howTitle: "كيف نعمل",
      howDesc: "خطوات عملنا المبسطة لضمان نجاح مشروعك",
      btn: "احجز جلستك المجانية"
    },
    en: {
      howTitle: "How We Work",
      howDesc: "Our simplified steps to ensure your project's success",
      btn: "Book Your Free Session"
    }
  };

  const t = content[lang] || content.ar;

  return (
    <Box sx={{ py: 10, backgroundColor: "#fff", direction: isRtl ? 'rtl' : 'ltr' }}>
      <Container maxWidth="lg">
        <Typography 
          variant="body1" 
          align="center" 
          sx={{ color: "#47C1CA", mb: 1, fontSize: 18, fontFamily: "Cairo" }}
        >
          {t.howTitle}
        </Typography>
        
        <Typography 
          variant="h4" 
          align="center" 
          sx={{ fontWeight: 700, color: "#27307F", mb: 15, fontFamily: "Cairo", fontSize: "2.2rem" }}
        >
          {t.howDesc}
        </Typography>
        
        {/* زر التنقل عبر السيرفر باستخدام Link بدلاً من onClick */}
        <Box sx={{ marginTop: "2rem", textAlign: "center", marginBottom: "3rem" }}>
          <Link href={`${prefix}/${paths.contact}`} style={{ textDecoration: 'none' }}>
            <CTAButton label={t.btn} />
          </Link>
        </Box>
      </Container>
    </Box>
  );
}