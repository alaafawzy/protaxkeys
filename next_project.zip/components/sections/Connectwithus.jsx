"use client";

import React, { useState } from "react";
import { Box, Container, Grid, Typography } from "@mui/material";
import InputField, { PhoneField } from "@/components/InputField";
import { useTheme } from "@emotion/react";
import { useTranslation } from "react-i18next";
import { useForm } from "react-hook-form";
import { joiResolver } from "@hookform/resolvers/joi";
import Joi from "joi";
import { matchIsValidTel } from "mui-tel-input";
import { ContactUsApi } from "@/Api";

export default function Connectwithus() {
  const theme = useTheme();
  const { t } = useTranslation();
  const Contactus = t("Contactus");
  const Validation = t("Validation");
  const [isLoading, setisLoading] = useState(false);

  const schema = Joi.object({
    name: Joi.string().required(),
    company_name: Joi.string().optional().allow(""),
    email: Joi.string().required().email({ minDomainSegments: 2, tlds: { allow: ["com", "net"] } }),
    Phone: Joi.string().required().custom((value, helpers) => {
        if (matchIsValidTel(value, { onlyCountries: ["AE", "SA", "EG"] })) return value;
        return helpers.error("string.pattern.base");
    }),
    details: Joi.string().required(),
  });

  const { register, handleSubmit, control, formState: { errors } } = useForm({ resolver: joiResolver(schema) });
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const onSubmit = async (inputs) => {
    setisLoading(true);
    const success = await ContactUsApi(inputs.name, inputs.company_name, inputs.email, inputs.Phone, inputs.details);
    if (success.status === 200) setSuccessMessage(Contactus.SentSucc);
    else setErrorMessage(Contactus.SentErr);
    setisLoading(false);
  };

  return (
    <Box sx={{ minHeight: "100vh", display: "flex", flexDirection: "column", padding: "4rem 2rem", direction: theme.direction }}>
      <Container maxWidth="lg">
        <Box sx={{ textAlign: "center", marginBottom: "4rem" }}>
          <Typography variant="h3" sx={{ fontFamily: "Cairo", fontWeight: "700", color: "#131F89" }}>{Contactus.Title}</Typography>
          <Typography sx={{ fontFamily: "Cairo", color: "#666" }}>{Contactus.Desc}</Typography>
        </Box>
      </Container>
      <Box sx={{ width: "100vw", background: "rgba(71, 193, 202, 0.08)", padding: "4rem 0" }}>
        <Container maxWidth="md">
          <Box component="form" onSubmit={handleSubmit(onSubmit)} sx={{ background: "#FFFFFF", padding: "3rem", borderRadius: "16px" }}>
            <Grid container spacing={1}>
              <Grid item xs={12} md={6}><InputField label={Contactus.Name} ele="name" register={register} errors={errors} /></Grid>
              <Grid item xs={12} md={6}><InputField label={Contactus.Company} ele="company_name" register={register} errors={errors} /></Grid>
              <Grid item xs={12}><InputField label={Contactus.Email} ele="email" register={register} errors={errors} /></Grid>
              <Grid item xs={12}><PhoneField label={Contactus.Phone} ele="Phone" register={register("Phone")} errors={errors} control={control} /></Grid>
              <Grid item xs={12}><InputField label={Contactus.Message} ele="details" register={register} errors={errors} multiline /></Grid>
              <Grid item xs={12}><button type="submit" disabled={isLoading} style={{ width: "100%", padding: "1rem" }}>{isLoading ? "...جاري الإرسال" : Contactus.Submit}</button></Grid>
            </Grid>
          </Box>
        </Container>
      </Box>
    </Box>
  );
}