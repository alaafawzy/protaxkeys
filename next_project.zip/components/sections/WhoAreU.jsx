"use client";

import React from "react";
import { Grid, Container, Box } from "@mui/material";
import { useTranslation } from "react-i18next";
import { useRouter } from "next/navigation";
import { useTheme } from "@emotion/react";
import CTAButton from "@/components/helpfulComp/CTAButton";
import { useLangPrefix } from "@/hooks/useLangPrefix";
import { getPagePathsForLang } from "@/config/pagePaths";

export default function WhoAreU() {
  const theme = useTheme();
  const { t, i18n } = useTranslation();
  const who = t("who");
  const { serv1, serv2, serv3 } = t("OurServises");
  const router = useRouter();
  const prefix = useLangPrefix();
  const paths = getPagePathsForLang(i18n.language);
  const skills = "/images/who we are/skills.png";
  const financial = "/images/who we are/financial.png";
  const whyus = "/images/who we are/whyus.png";

  return (
    <Grid className="who-we-are">
      <Container>
        <Grid
          container
          xs={11}
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            marginBottom: "3rem",
            direction: theme.direction === 'rtl' ? 'ltr' : 'rtl',
          }}
        >
          <Box
            sx={{
              fontFamily: "Cairo",
              fontSize: "2rem",
              fontWeight: "700",
              textAlign: "center",
              color: "#27307F",
              marginBottom: {
                xs: "2rem",
              },
              marginTop: "3rem",
            }}
          >
            {who?.mainTitle}
          </Box>
          <Box
            sx={{
              fontFamily: "Cairo",
              fontSize: {
                xs: "16px",
                md: "24px",
              },
              fontWeight: "500",
              lineHeight: "30px",
              textAlign: "center",
              color: "#B8B8B8",
              width: {
                xs: "100%",
                md: "70%",
              },
              marginTop: "-20px",
            }}
          >
            {who?.mainDesc}
          </Box>
        </Grid>
        <Grid
          container
          sx={{
            justifyContent: { xs: "center", md: "space-between" },
          }}
        >
          <SectionDetails image={skills} title={serv3?.title} desc={serv3?.desc} second={false} />
          <SectionDetails image={financial} title={serv2?.title} desc={serv2?.desc} second={true} />
          <SectionDetails image={whyus} title={serv1?.title} desc={serv1?.desc} second={false} />
        </Grid>
        <Box sx={{ marginTop: "2rem", textAlign: "center", marginBottom: "3rem" }}>
          <CTAButton
            label={t('Book.btn')}
            onClick={() => router.push(`${prefix}/${paths.contact}`)}
          />
        </Box>
      </Container>
    </Grid>
  );
}

export function SectionDetails({ image, title, desc, second }) {
  return (
    <Grid
      md={3.8}
      xs={11}
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        marginBottom: { xs: "2rem" },
      }}
    >
      <Box>
        <img
          src={typeof image === 'object' && image !== null ? image.src : image}
          alt={title}
          style={{ height: second ? "170px" : "150px", objectFit: "contain" }}
        />
      </Box>

      <Box
        sx={{
          fontFamily: "Cairo",
          fontSize: "20px",
          fontWeight: 700,
          lineHeight: "30px",
          textAlign: "center",
          color: "#27307F",
          marginTop: "2rem",
        }}
      >
        {title}
      </Box>

      <Box
        sx={{
          fontFamily: "Cairo",
          fontSize: "16px",
          fontWeight: 400,
          lineHeight: "24px",
          textAlign: "center",
          color: "#333333",
          marginTop: "0.5rem",
        }}
      >
        {desc}
      </Box>
    </Grid>
  );
}