"use client";

import React, { useState, useEffect } from "react";
import { Box, Grid, Container } from "@mui/material";
import InfiniteCarousel from "@/components/NewCarousel"; // مسار مصحح
import { useTranslation } from "react-i18next";
import api from "@/Api"; // مسار مصحح

export default function OurSystems() {
  const { t } = useTranslation();
  const partners = t("Systems");
  const [systemPartners, setSystemPartners] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSystemPartners = async () => {
      try {
        const response = await api.get('/system-partners/');
        setSystemPartners(response.data);
      } catch (error) { console.error(error); }
      finally { setLoading(false); }
    };
    fetchSystemPartners();
  }, []);

  return (
    <Grid container sx={{ paddingTop: "2rem", marginBottom: "4rem" }}>
      <Container sx={{ display: "flex", justifyContent: "center", alignItems: "center", flexDirection: "column" }}>
        <Grid container sx={{ fontFamily: "Cairo", fontSize: "2.2rem", fontWeight: "700", justifyContent: "center", marginBottom: 5 }}>
          {partners}
        </Grid>
        <Grid item md={12} xs={11} container sx={{ display: "flex", justifyContent: "space-between", padding: "1rem 0", bgcolor: "rgba(71, 193, 202, 0.1)", borderRadius: 25, overflow: "hidden", marginTop: 5 }}>
          {loading ? (
            <Box sx={{ textAlign: 'center', width: '100%', py: 4 }}>Loading...</Box>
          ) : systemPartners.length > 0 ? (
            <InfiniteCarousel items={systemPartners} />
          ) : (
            <Box sx={{ textAlign: 'center', width: '100%', py: 4 }}>No system partners available</Box>
          )}
        </Grid>
      </Container>
    </Grid>
  );
}