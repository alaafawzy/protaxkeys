"use client";

import React, { useEffect, useState } from "react";
import { Grid, Box } from "@mui/material";
import { useTranslation } from "react-i18next";
import { useTheme } from "@emotion/react";
import api from "@/Api";
import ReviewCarousel from "@/components/feedbackCarousel";

export default function Feedback() {
  const { t } = useTranslation();
  const { feed1 } = t("Feedback");
  const theme = useTheme();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await api.get('/all-comments/');
        setData(Array.isArray(response.data) ? response.data : []);
      } catch (error) { console.error(error); }
      finally { setLoading(false); }
    };
    fetchData();
  }, []);

  return (
    <Grid sx={{ width: "100%", display: "flex", flexDirection: "column", direction: theme.direction === 'rtl' ? 'ltr' : 'rtl', fontFamily: "Cairo" }}>
      <Box sx={{ display: "flex", flexDirection: "column", textAlign: "center", marginTop: 5 }}>
        <Box sx={{ color: "#27307F", fontWeight: "700", fontSize: "2.2rem" }}>{feed1?.whatTheySay}</Box>
        <Box>{feed1?.subtitle}</Box>
        <Grid dir={theme.direction === 'rtl' ? 'ltr' : 'rtl'} sx={{ width: "100%", display: 'flex', marginTop: 5 }}>
          <ReviewCarousel items={data} />
        </Grid>
      </Box>
    </Grid>
  );
}