"use client";

import React, { useState, useEffect } from "react";
import { Container, Box } from "@mui/material";
import { useTranslation } from "react-i18next";
import { Question } from "@/components/Question";
import { useTheme } from "@emotion/react";
import api from '@/Api';

export default function FAQ() {
  const { t } = useTranslation();
  const { title1 } = t("CommonQues");
  const theme = useTheme();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await api.get('/faq/');
        setData(Array.isArray(response.data) ? response.data : []);
      } catch (error) { console.error(error); }
      finally { setLoading(false); }
    };
    fetchData();
  }, []);

  if (loading) return <p>Loading...</p>;

  return (
    <Container sx={{ display: "flex", flexDirection: "column", textAlign: "end", fontFamily: "Cairo", "& > div:not(:last-child)": { marginBottom: "1rem" } }}>
      <Box sx={{ display: "flex", flexDirection: "column", textAlign: "center", fontFamily: "Cairo" }}>
        <Box sx={{ color: "#27307F", fontWeight: "700", fontSize: "2.2rem", marginTop: 3, marginBottom: 3 }}>
          {title1}
        </Box>
      </Box>
      <Box>
        {data?.map((Q, idx) => (
          <Question key={idx} ques={theme.direction === 'rtl' ? Q.arabic_question : Q.english_question} ans={theme.direction === 'rtl' ? Q.arabic_answer : Q.english_answer} bg={"#F9FAFB"} />
        ))}
      </Box>
    </Container>
  );
}