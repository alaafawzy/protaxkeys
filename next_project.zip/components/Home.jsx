import React from "react";
import { Grid } from "@mui/material";
// استيراد الأقسام من المجلد الجديد
import HomeStarting from "./sections/HomeStarting";
import WhoAreU from "./sections/WhoAreU";
import HowWeWork from "./sections/HowWeWork";
// import Bundles from "./sections/Bundles";
// import FAQ from "./sections/FAQ";
// import OurSystems from "./sections/OurSystems";
// import Feedback from "./sections/Feedback";

export default async function Home({ params }) {
  return (
    <Grid sx={{ "& > div": { marginBottom: "5rem" } }}>
      {/* نمرر الـ params لأي مكون يحتاج إلى معرفة اللغة ليعمل Server-Side */}
      <HomeStarting params={params} />
      
      {/* المكونات التي لا تزال Client Components يمكنك تركها كما هي (لا تحتاج params) */}
      <WhoAreU /> 

      {/* المكون الذي حولناه للتو إلى Server Component */}
      <HowWeWork params={params} />
      {/*<Bundles />
      <FAQ />
      <OurSystems />
      <Feedback /> */}
    </Grid>
  );
}