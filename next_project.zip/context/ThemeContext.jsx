"use client";
import { createContext } from 'react';
export const ThemeContext = createContext({ theme1: null, setThemeLang: () => {} });